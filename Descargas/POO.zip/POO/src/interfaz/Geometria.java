package interfaz;

public interface Geometria 
{	
	double area();
	double perimetro();
}

	
