package interfaz;

public class TestGeometria {

	public static void main(String[] args) {
	
		Rectangulo  rectangulo = new Rectangulo(4,2);
		Geometria interfaz = rectangulo;
		System.out.println("area del rectangulo es igual  "+interfaz.area());
		System.out.println("el perimetro del rectangulo es : "+interfaz.perimetro());
		interfaz = new Circulo(2);	
		System.out.println("el perimetro del circulo es: "+interfaz.perimetro());
		System.out.println("el area del circulo es: "+interfaz.area());
		
	}
		

}
