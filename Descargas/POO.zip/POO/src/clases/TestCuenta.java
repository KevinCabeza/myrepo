package clases;

public class TestCuenta {

	public static void main(String[] args)
	{	
		Cuenta c1 = new Cuenta("Jose","ES001",0.05,100);
		Cuenta c2 = new Cuenta(c1);
		System.out.println("El saldo de la cuenta 1 es: " + c1.getSaldo());
		System.out.println("El saldo de la cuenta 2 es: " + c2.getSaldo());
		System.out.println("El nombre de la cuenta 1 es: " + c1.getNombre());
		c1.ingreso(100);
		c1.reintegro(50);
		System.out.println("El saldo de la cuenta 1 es: " + c1.getSaldo());
		c2.ingreso(200);
		c2.reintegro(150);
		System.out.println("El saldo de la cuenta 2 es: " + c2.getSaldo());
		c2.mostrar();
	}

}
