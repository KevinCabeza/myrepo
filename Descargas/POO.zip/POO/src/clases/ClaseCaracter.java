package clases;

import java.io.IOException;

public class ClaseCaracter {

	public static void main(String[] args) throws IOException {
		/*char car ='Z';
		Character caracter = new Character('A');
		System.out.println("el caracter es " + caracter);
		System.out.println("introduzca un caracter: ");
		char  c = (char) System.in.read();
		System.out.println("el caracter es " + c);
		if(Character.isDigit(c)) {
			System.out.println("es un número");
		}else if(Character.isLetter(c))
		{
			System.out.println("es una letra");
			if(Character.isUpperCase(c)) {
				System.out.println("el caracter está en mayúscula");
				c = Character.toLowerCase(c);
				System.out.println("lo hemos convertido a minúscula " + c);
			}else {
				c = Character.toUpperCase(c);
				System.out.println("lo hemos convertido a mayúscula " + c);
			}
			
	    	
			
		}
		*/
		for(int letra = 'a'; letra <= 'z'; letra++)
			System.out.print(letra + " ");
		System.out.println();
		for(char letra = 'a'; letra <= 'z'; letra++)
			System.out.print(letra + " ");
	}

}
