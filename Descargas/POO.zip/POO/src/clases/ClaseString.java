package clases;

import java.util.Scanner;

public class ClaseString {

	public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in);
		String a = "Hola Mundo";
		System.out.println(a);
		String cadena = entrada.nextLine();
		System.out.println(cadena);
		int l = a.length();
		System.out.println(l);
		char c = a.charAt(3);
		System.out.println(c);
		String S1 = a;
		String S2 = S1;
		String S3 = "Hola mundo";
		if(S1.equals(S2)) {
			System.out.println("Son iguales.");
		}
		if(S1.equalsIgnoreCase(S3)) {
			System.out.println("Son iguales sin contar las mayusculas.");
		}
		System.out.println("Comparacion lexicografica.");
		String cadena1 = "Pepe";
		String cadena2 = "Pepa";
		if(cadena1.compareTo(cadena2) == 0) {
			System.out.println("cadena1 y cadena2 son iguales.");
		}
		else if(cadena1.compareTo(cadena2) > 0){
			System.out.println(cadena1 + " alfabeticamente va después de " + cadena2);
		}
		else {
			System.out.println(cadena2 + " alfabeticamente va después de " + cadena1);
		}
		System.out.println(S1.indexOf('u'));
		S2 = S2.replace('o', 'e');
		System.out.println(S2);
		double numero = 5.6;
		String num = String.valueOf(numero);
		System.out.println(num);
		System.out.println("Introduzca la cadena:");
		String S4 = entrada.nextLine();
		System.out.println(S4);
		System.out.println("Cadena invertida: ");
		for(int i = S4.length(); i > 0; i--) {
			System.out.print(S4.charAt(i-1));
		}
	}

}
