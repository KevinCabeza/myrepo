package herenciapolimorfismo;

public class TestVehiculo {

	public static void main(String[] args)
	{	
		Vehiculo vehiculo = new Vehiculo(4,"diesel","ford","rojo","tdi1.5");
		System.out.println("datos del vehiculo:");
		System.out.println(vehiculo.mostrarDatos());
		System.out.println("datos del camion:");
		Camion camion = new Camion(10,"diesel","volvo","blanco","tdi5000",10000);
		System.out.println(camion.mostrarDatos());
		Coche coche=new Coche(4,"Gasolina","Seat","Azul","Tsi 1.6",5);
		System.out.println(coche.mostrarDatos());
	}

}
